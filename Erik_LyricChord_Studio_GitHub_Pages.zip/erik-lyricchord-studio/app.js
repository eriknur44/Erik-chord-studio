(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const sample = `[VERSE 1]
[G]I found a love [D]for me
[Em]Darling just dive [C]right in
[G]And follow my [D]lead
[Em]Well I found a girl [C]beautiful and sweet

[CHORUS]
[G]Baby, I'm [D]dancing in the dark
[Em]With you between [C]my arms
[G]Barefoot on the [D]grass
[Em]Listening to our [C]favorite song`;
  let transpose = 0, fontSize = 22, animation = null, lastTime = 0, running = false;
  const notes = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
  const flatMap = {'Db':'C#','Eb':'D#','Gb':'F#','Ab':'G#','Bb':'A#'};

  function transposeChord(chord) {
    // Transpose the root and optional slash-bass independently; preserve chord suffixes.
    return chord.replace(/([A-G])([#b]?)([^/]*)(?:\/([A-G])([#b]?))?/g, (full, n, accidental, suffix, bass, bassAcc) => {
      const root = notes.indexOf(flatMap[n + accidental] || n + accidental);
      if (root < 0) return full;
      const shifted = notes[(root + transpose + 1200) % 12];
      if (bass) {
        const bi = notes.indexOf(flatMap[bass + (bassAcc || '')] || bass + (bassAcc || ''));
        return shifted + suffix + (bi < 0 ? '/' + bass + (bassAcc || '') : '/' + notes[(bi + transpose + 1200) % 12]);
      }
      return shifted + suffix;
    });
  }

  function addUnit(parent, chord, lyric) {
    const unit = document.createElement('span'); unit.className = 'chord-unit';
    const c = document.createElement('span'); c.className = 'chord-text'; c.textContent = chord ? transposeChord(chord) : ' ';
    const l = document.createElement('span'); l.className = 'lyric-text'; l.textContent = lyric;
    l.style.fontSize = fontSize + 'px';
    unit.append(c, l); parent.append(unit);
  }

  function render() {
    $('displayTitle').textContent = $('songTitle').value.trim() || 'Untitled';
    $('displayArtist').textContent = $('songArtist').value.trim() || 'Unknown artist';
    $('transposeValue').textContent = (transpose > 0 ? '+' : '') + transpose + ' semitone';
    $('fontValue').textContent = fontSize + ' px';
    const display = $('lyricsDisplay'); display.replaceChildren();
    $('lyricsInput').value.split(/\r?\n/).forEach(line => {
      const section = line.match(/^\s*\[([A-Z0-9 _-]+)\]\s*$/i);
      if (section) {
        const el = document.createElement('div'); el.className = 'section-label'; el.textContent = section[1];
        display.append(el); return;
      }
      if (!line.trim()) { const blank = document.createElement('div'); blank.className = 'blank-line'; display.append(blank); return; }
      const row = document.createElement('div'); row.className = 'lyric-line';
      const re = /\[([^\]]+)\]/g; let match, cursor = 0;
      while ((match = re.exec(line)) !== null) {
        const before = line.slice(cursor, match.index);
        if (before) addUnit(row, '', before);
        const next = line.indexOf('[', re.lastIndex);
        const end = next < 0 ? line.length : next;
        addUnit(row, match[1], line.slice(re.lastIndex, end));
        cursor = end; re.lastIndex = end;
      }
      if (cursor < line.length) addUnit(row, '', line.slice(cursor));
      if (!line.includes('[')) addUnit(row, '', line);
      display.append(row);
    });
  }

  function setStatus(message) { $('playStatus').textContent = message.toUpperCase(); }
  function stop(status = 'Dijeda') {
    running = false;
    if (animation) cancelAnimationFrame(animation);
    animation = null; lastTime = 0; $('playBtn').textContent = '▶ Mulai scroll'; setStatus(status);
  }
  function step(time) {
    if (!running) return;
    if (!lastTime) lastTime = time;
    const delta = Math.min(time - lastTime, 60); lastTime = time;
    const area = $('lyricsDisplay');
    area.scrollTop += Number($('speedRange').value) * delta / 16.67;
    if (area.scrollTop + area.clientHeight >= area.scrollHeight - 2) { stop('Selesai'); return; }
    animation = requestAnimationFrame(step);
  }

  function getSongs() {
    try { return JSON.parse(localStorage.getItem('erik-lyricchord-songs') || '[]'); }
    catch { return []; }
  }
  function refreshSongs() {
    const list = $('songList'); list.replaceChildren();
    const songs = getSongs();
    if (!songs.length) { const p = document.createElement('p'); p.className = 'empty'; p.textContent = 'Belum ada lagu tersimpan.'; list.append(p); return; }
    songs.forEach((song, index) => {
      const row = document.createElement('div'); row.className = 'song-item';
      const name = document.createElement('span'); name.textContent = song.title || 'Tanpa judul';
      const open = document.createElement('button'); open.textContent = 'Buka';
      open.addEventListener('click', () => {
        stop('Lagu dibuka'); $('songTitle').value = song.title || ''; $('songArtist').value = song.artist || '';
        $('lyricsInput').value = song.lyrics || ''; transpose = 0; render(); $('lyricsDisplay').scrollTop = 0;
      });
      const remove = document.createElement('button'); remove.textContent = 'Hapus';
      remove.addEventListener('click', () => {
        const updated = getSongs(); updated.splice(index, 1); localStorage.setItem('erik-lyricchord-songs', JSON.stringify(updated)); refreshSongs();
      });
      row.append(name, open, remove); list.append(row);
    });
  }

  $('lyricsInput').value = sample;
  $('applyBtn').addEventListener('click', () => { stop('Perubahan diterapkan'); render(); $('lyricsDisplay').scrollTop = 0; });
  $('playBtn').addEventListener('click', () => {
    if (running) return;
    running = true; lastTime = 0; $('playBtn').textContent = '▶ Sedang scroll'; setStatus('Auto scroll aktif');
    animation = requestAnimationFrame(step);
  });
  $('pauseBtn').addEventListener('click', () => stop());
  $('topBtn').addEventListener('click', () => { stop('Kembali ke awal'); $('lyricsDisplay').scrollTop = 0; });
  $('speedRange').addEventListener('input', () => $('speedValue').textContent = Number($('speedRange').value).toFixed(1));
  $('fontDown').addEventListener('click', () => { fontSize = Math.max(14, fontSize - 2); render(); });
  $('fontUp').addEventListener('click', () => { fontSize = Math.min(40, fontSize + 2); render(); });
  $('transposeDown').addEventListener('click', () => { transpose--; render(); });
  $('transposeUp').addEventListener('click', () => { transpose++; render(); });
  $('transposeReset').addEventListener('click', () => { transpose = 0; render(); });
  $('songTitle').addEventListener('input', render); $('songArtist').addEventListener('input', render);
  $('clearBtn').addEventListener('click', () => { stop(); $('lyricsInput').value = ''; render(); });
  $('newSongBtn').addEventListener('click', () => {
    stop(); $('songTitle').value = ''; $('songArtist').value = ''; $('lyricsInput').value = ''; transpose = 0; render(); $('songTitle').focus();
  });
  $('saveSongBtn').addEventListener('click', () => {
    const song = { title: $('songTitle').value.trim() || 'Tanpa judul', artist: $('songArtist').value.trim(), lyrics: $('lyricsInput').value };
    const songs = getSongs(); const idx = songs.findIndex(s => s.title === song.title && s.artist === song.artist);
    if (idx >= 0) songs[idx] = song; else songs.push(song);
    try { localStorage.setItem('erik-lyricchord-songs', JSON.stringify(songs)); refreshSongs(); setStatus('Lagu tersimpan'); }
    catch { setStatus('Penyimpanan penuh'); }
  });
  $('exportBtn').addEventListener('click', () => {
    const blob = new Blob([$('lyricsInput').value], {type:'text/plain;charset=utf-8'});
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = (($('songTitle').value || 'lagu').replace(/[^\w\- ]/g, '') || 'lagu') + '.txt'; a.click(); URL.revokeObjectURL(url);
  });
  $('importBtn').addEventListener('click', () => $('importFile').click());
  $('importFile').addEventListener('change', async event => {
    const file = event.target.files[0]; if (!file) return;
    $('lyricsInput').value = await file.text(); $('songTitle').value = file.name.replace(/\.txt$/i, '');
    transpose = 0; render(); setStatus('File diimpor'); event.target.value = '';
  });
  $('fullscreenBtn').addEventListener('click', async () => {
    try { if (!document.fullscreenElement) await document.documentElement.requestFullscreen(); else await document.exitFullscreen(); }
    catch { setStatus('Fullscreen tidak tersedia'); }
  });
  render(); refreshSongs();
})();